# SCENTIVA — Luxury Multi-Brand Fragrance Marketplace
> **SINCE 2026** • Haute Parfumerie & Niche Olfactory Vault

A comprehensive, responsive e-commerce web application prototype for **SCENTIVA**, built with a mobile-first philosophy, desktop web experience, and an interactive operational admin demo.

---

## 🌟 Visual & Design System

- **Brand Colors:**
  - `Plum 950`: `#321027` (Deepest brand surface, footer, dark hero)
  - `Plum 900`: `#451333` (Primary brand identity)
  - `Plum 800`: `#5B1B43` (Hover & dark active surfaces)
  - `Blush 300`: `#E9B7D8` (Logo accent on dark surfaces)
  - `Blush 200`: `#F2D2E7` (Soft accent surface)
  - `Blush 100`: `#FAEAF4` (Subtle blush background)
  - `Rose 500`: `#B85B88` (Accent actions & badge highlights)
  - `Gold 500`: `#C7A66A` (Prestige highlights & luxury badges)
  - `Canvas Background`: `#FAF8F7`
- **Typography:**
  - Headings & Editorial: `Cormorant Garamond` (Google Serif)
  - UI & Controls: `Inter` (Sans-serif with tabular numerals)
- **3D Interactive Hero:**
  - Real-time 3D WebGL Perfume Flacon with cursor parallax tilt, golden botanical scent sparks, glass transmission, and liquid depth.

---

## 🚀 Key Features & Interactions

1. **Customer Storefront (`/`)**:
   - Dynamic Announcement Bar with rotating promotional campaigns and voucher copy CTA.
   - Interactive 3D Perfume Flacon with mouse tracking and gold sparkles.
   - Brand Ticker & Directory featuring Christian Dior, CHANEL, Tom Ford, YSL, Versace, Armani, Creed, Byredo, Gucci, Prada.
   - Category Highlights: *For Her*, *For Him*, *Unisex*, *Luxury & Niche*, *Everyday Fresh*, *Gift Sets*.
   - Best Sellers product grid with size switcher, quick add to bag, wishlist toggle, and Quick View modal.
   - AI Scent Matchmaker quiz teaser.
   - Fragrance Journal & Masterclasses editorial section.
   - Trust strip: 100% Authentic, Thermal Expedited Delivery, 7-Day Returns, Concierge.

2. **Catalog & Search (`/shop`)**:
   - Desktop persistent filter sidebar (House, Family, Gender, Price Slider, Concentration).
   - Mobile filter & sort bottom sheet.
   - Real-time autocomplete search flyout for perfumes, houses, and olfactory notes.
   - Multi-parameter sorting (Recommended, Price Low-High, Price High-Low, Rating, New Arrivals).

3. **Product Detail Page (`/product/:slug`)**:
   - High-definition multi-angle gallery with thumbnail selector.
   - Size & Concentration variant selector with instant price and MRP calculations.
   - Olfactory Notes Pyramid (Top, Heart, Base notes).
   - Longevity on skin and Sillage radar gauges.
   - Live Indian PIN code delivery serviceability checker.
   - Verified Connoisseur Reviews and "Write a Review" submission modal.
   - Mobile sticky bottom purchase bar.

4. **AI Fragrance Finder Quiz (`/find-your-scent`)**:
   - 5-step guided consultation (Fragrance family, Occasion, Intensity/Sillage, Budget, Gender).
   - Dynamic results engine with fit score % and explanation breakdown.
   - Celebratory particle confetti.

5. **Cart & Wishlist Engine (`/cart`, `/wishlist`)**:
   - Slide-over luxury cart drawer + full cart page.
   - Free shipping threshold progress bar (`₹999` minimum).
   - Promotional voucher code applicator (`WELCOME10`, `LUXURY20`, `FIRSTSCENT`).
   - LocalStorage persistence across page reloads.

6. **End-to-End Checkout & Live Tracking (`/checkout`, `/account/orders/:id`)**:
   - 3-step checkout flow (Address selection & new address modal, Delivery method, Demo payment selection: UPI/QR, Cards, NetBanking, COD).
   - Place Demo Order generates mock order reference with celebratory confetti.
   - 5-Stage Live Shipment Tracker (*Order Placed* → *Processing* → *Shipped* → *Out for Delivery* → *Delivered*) with an interactive status simulator.

7. **Admin Operations Portal (`/admin`)**:
   - Dashboard with revenue metrics (`₹4,28,750`), order trends bar chart, conversion rates, and live orders stream.
   - Products Management table with brand filters, search, inline price/stock adjustments, and "Add New Flacon" modal.
   - Order Management with status filters and one-click status transitions.
   - Real-time Inventory Replenishment with low-stock warnings.
   - Promotions and Coupon Voucher manager.
   - Store settings and shipping threshold rules.

---

## 🛠️ Technology Stack

- **Frontend:** React 18 + TypeScript + Vite
- **Routing:** React Router v6
- **Styling:** TailwindCSS + Custom Design Tokens (`src/styles/tokens.css`, `src/styles/index.css`)
- **Icons:** Lucide React (`lucide-react`)
- **3D & WebGL:** Three.js + `@react-three/fiber` + `@react-three/drei`
- **Animations:** GSAP + Canvas Confetti
- **State & Storage:** React Context API + LocalStorage persistence

---

## 📦 How to Run Locally

1. **Install dependencies:**
   ```bash
   npm install
   ```

2. **Start Vite development server:**
   ```bash
   npm run dev
   ```

3. **Open in browser:**
   ```
   http://localhost:5173
   ```

4. **Build production bundle:**
   ```bash
   npm run build
   ```

---

## 🗺️ Route Inventory

| Route | Screen Name | Description |
|---|---|---|
| `/` | Home | Master luxury storefront with 3D flacon & best sellers |
| `/shop` | All Perfumes | Filterable and searchable fragrance catalog |
| `/brands` | Brand Directory | A-Z list of luxury perfume houses |
| `/brands/:slug` | Brand Detail | Heritage bio and brand-specific flacons |
| `/categories/:slug` | Collections | Dedicated category listing (For Her, For Him, etc.) |
| `/product/:slug` | Product Details | Gallery, notes pyramid, size selector, reviews |
| `/find-your-scent` | Scent Matcher | 5-step interactive AI fragrance quiz |
| `/wishlist` | Saved Flacons | Wishlist items with move to bag action |
| `/cart` | Shopping Bag | Quantity steppers, voucher codes, totals |
| `/checkout` | Checkout | Address, delivery speed, demo payment |
| `/order/success` | Order Confirmation | Confirmed order summary & tracking link |
| `/account` | My Account | Profile, order history, address book |
| `/account/orders/:id` | Order Tracking | 5-stage live shipment visualizer |
| `/offers` | Promotions | Copyable coupons & gift campaigns |
| `/stories` | Fragrance Journal | Editorial articles & scent layering masterclasses |
| `/help` | Support & FAQ | FAQs, Authenticity guarantee, and contact concierge |
| `/admin` | Admin Dashboard | Revenue charts, top products, recent orders |
| `/admin/products` | Product Management | Product table, price/stock edit, add flacon |
| `/admin/orders` | Order Fulfillment | Orders table and live status updater |
| `/admin/inventory` | Inventory Control | Stock adjustments and low-stock alerts |
| `/admin/promotions` | Promotion Manager | Coupon discount editor |
| `/admin/settings` | Store Settings | Store info, shipping thresholds |
