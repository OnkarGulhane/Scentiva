import React from 'react';
import { NavLink, useLocation } from 'react-router-dom';
import { Home, Compass, Sparkles, Heart, User, ShoppingBag } from 'lucide-react';
import { useStore } from '../../context/StoreContext';

export const MobileBottomNav: React.FC = () => {
  const { wishlist, cartCount, setIsCartDrawerOpen } = useStore();
  const location = useLocation();

  // Hide on admin routes or full screen checkout to prevent clutter
  if (location.pathname.startsWith('/admin') || location.pathname === '/checkout') {
    return null;
  }

  return (
    <div className="fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-md border-t border-neutral-200/90 lg:hidden shadow-modal pb-safe">
      <div className="grid grid-cols-5 h-14 max-w-md mx-auto">
        <NavLink
          to="/"
          className={({ isActive }) =>
            `flex flex-col items-center justify-center gap-0.5 text-[10px] font-medium transition-colors ${
              isActive ? 'text-brand-plum-900 font-semibold' : 'text-neutral-500 hover:text-neutral-800'
            }`
          }
        >
          <Home className="w-5 h-5" />
          <span>Home</span>
        </NavLink>

        <NavLink
          to="/shop"
          className={({ isActive }) =>
            `flex flex-col items-center justify-center gap-0.5 text-[10px] font-medium transition-colors ${
              isActive ? 'text-brand-plum-900 font-semibold' : 'text-neutral-500 hover:text-neutral-800'
            }`
          }
        >
          <Compass className="w-5 h-5" />
          <span>Shop</span>
        </NavLink>

        <NavLink
          to="/find-your-scent"
          className={({ isActive }) =>
            `flex flex-col items-center justify-center gap-0.5 text-[10px] font-medium transition-colors relative ${
              isActive ? 'text-brand-plum-900 font-bold' : 'text-brand-rose-500 hover:text-brand-plum-900'
            }`
          }
        >
          <div className="p-1 rounded-full bg-brand-blush-100">
            <Sparkles className="w-4 h-4 text-brand-plum-900" />
          </div>
          <span>Finder</span>
        </NavLink>

        <NavLink
          to="/wishlist"
          className={({ isActive }) =>
            `flex flex-col items-center justify-center gap-0.5 text-[10px] font-medium transition-colors relative ${
              isActive ? 'text-brand-plum-900 font-semibold' : 'text-neutral-500 hover:text-neutral-800'
            }`
          }
        >
          <div className="relative">
            <Heart className="w-5 h-5" />
            {wishlist.length > 0 && (
              <span className="absolute -top-1 -right-2 w-3.5 h-3.5 bg-brand-rose-500 text-white rounded-full text-[9px] font-bold flex items-center justify-center">
                {wishlist.length}
              </span>
            )}
          </div>
          <span>Saved</span>
        </NavLink>

        <NavLink
          to="/account"
          className={({ isActive }) =>
            `flex flex-col items-center justify-center gap-0.5 text-[10px] font-medium transition-colors ${
              isActive ? 'text-brand-plum-900 font-semibold' : 'text-neutral-500 hover:text-neutral-800'
            }`
          }
        >
          <User className="w-5 h-5" />
          <span>Account</span>
        </NavLink>
      </div>
    </div>
  );
};
