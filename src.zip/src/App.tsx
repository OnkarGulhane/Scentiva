import React, { useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, useLocation } from 'react-router-dom';
import { StoreProvider } from './context/StoreContext';
import { AnnouncementBar } from './components/layout/AnnouncementBar';
import { Navbar } from './components/layout/Navbar';
import { Footer } from './components/layout/Footer';
import { MobileBottomNav } from './components/layout/MobileBottomNav';
import { CartDrawer } from './components/layout/CartDrawer';
import { QuickViewModal } from './components/common/QuickViewModal';
import { ToastContainer } from './components/common/Toast';
import { initSmoothScroll, destroySmoothScroll } from './motion/smoothScroll';

// Public Pages
import { HomePage } from './pages/HomePage';
import { ShopPage } from './pages/ShopPage';
import { SearchPage } from './pages/SearchPage';
import { BrandsPage } from './pages/BrandsPage';
import { BrandDetailPage } from './pages/BrandDetailPage';
import { CategoryDetailPage } from './pages/CategoryDetailPage';
import { ProductDetailPage } from './pages/ProductDetailPage';
import { FragranceFinderPage } from './pages/FragranceFinderPage';
import { WishlistPage } from './pages/WishlistPage';
import { CartPage } from './pages/CartPage';
import { CheckoutPage } from './pages/CheckoutPage';
import { OrderSuccessPage } from './pages/OrderSuccessPage';
import { OrderTrackingPage } from './pages/OrderTrackingPage';
import { AccountPage } from './pages/AccountPage';
import { SignInPage } from './pages/SignInPage';
import { SignUpPage } from './pages/SignUpPage';
import { AccountOrdersPage } from './pages/AccountOrdersPage';
import { AccountAddressesPage } from './pages/AccountAddressesPage';
import { OffersPage } from './pages/OffersPage';
import { GiftsPage } from './pages/GiftsPage';
import { StoriesPage } from './pages/StoriesPage';
import { StoryDetailPage } from './pages/StoryDetailPage';
import { HelpPolicyPages } from './pages/HelpPolicyPages';

// Admin Pages
import { AdminLayout } from './pages/admin/AdminLayout';
import { AdminLoginPage } from './pages/admin/AdminLoginPage';
import { AdminDashboardPage } from './pages/admin/AdminDashboardPage';
import { AdminProductsPage } from './pages/admin/AdminProductsPage';
import { AdminNewProductPage } from './pages/admin/AdminNewProductPage';
import { AdminBrandsPage } from './pages/admin/AdminBrandsPage';
import { AdminCategoriesPage } from './pages/admin/AdminCategoriesPage';
import { AdminInventoryPage } from './pages/admin/AdminInventoryPage';
import { AdminOrdersPage } from './pages/admin/AdminOrdersPage';
import { AdminCustomersPage } from './pages/admin/AdminCustomersPage';
import { AdminPromotionsPage } from './pages/admin/AdminPromotionsPage';
import { AdminContentPage } from './pages/admin/AdminContentPage';
import { AdminReportsPage } from './pages/admin/AdminReportsPage';
import { AdminSettingsPage } from './pages/admin/AdminSettingsPage';

// Scroll to top on route change & initialize smooth scrolling
const RouteObserver: React.FC = () => {
  const { pathname } = useLocation();

  useEffect(() => {
    window.scrollTo(0, 0);
  }, [pathname]);

  return null;
};

// Layout Shell for customer storefront
const StoreLayout: React.FC = () => {
  return (
    <div className="flex flex-col min-h-screen">
      <AnnouncementBar />
      <Navbar />
      <main className="flex-1">
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/shop" element={<ShopPage />} />
          <Route path="/search" element={<SearchPage />} />
          <Route path="/brands" element={<BrandsPage />} />
          <Route path="/brands/:slug" element={<BrandDetailPage />} />
          <Route path="/categories/:slug" element={<CategoryDetailPage />} />
          <Route path="/product/:slug" element={<ProductDetailPage />} />
          <Route path="/find-your-scent" element={<FragranceFinderPage />} />
          <Route path="/find-your-scent/results" element={<FragranceFinderPage />} />
          <Route path="/wishlist" element={<WishlistPage />} />
          <Route path="/cart" element={<CartPage />} />
          <Route path="/checkout" element={<CheckoutPage />} />
          <Route path="/checkout/payment" element={<CheckoutPage />} />
          <Route path="/order/success" element={<OrderSuccessPage />} />
          
          {/* Account Routes */}
          <Route path="/account" element={<AccountPage />} />
          <Route path="/account/sign-in" element={<SignInPage />} />
          <Route path="/account/sign-up" element={<SignUpPage />} />
          <Route path="/account/orders" element={<AccountOrdersPage />} />
          <Route path="/account/orders/:id" element={<OrderTrackingPage />} />
          <Route path="/account/addresses" element={<AccountAddressesPage />} />
          
          {/* Marketing & Policy Routes */}
          <Route path="/offers" element={<OffersPage />} />
          <Route path="/gifts" element={<GiftsPage />} />
          <Route path="/stories" element={<StoriesPage />} />
          <Route path="/stories/:slug" element={<StoryDetailPage />} />
          <Route path="/help" element={<HelpPolicyPages />} />
          <Route path="/contact" element={<HelpPolicyPages />} />
          <Route path="/policies/*" element={<HelpPolicyPages />} />
        </Routes>
      </main>
      <Footer />
      <MobileBottomNav />
    </div>
  );
};

export const App: React.FC = () => {
  useEffect(() => {
    const lenis = initSmoothScroll();
    return () => {
      destroySmoothScroll();
    };
  }, []);

  return (
    <StoreProvider>
      <Router>
        <RouteObserver />
        <Routes>
          {/* Admin Login Route */}
          <Route path="/admin/login" element={<AdminLoginPage />} />

          {/* Admin Demo Portal Routes */}
          <Route path="/admin" element={<AdminLayout />}>
            <Route index element={<AdminDashboardPage />} />
            <Route path="products" element={<AdminProductsPage />} />
            <Route path="products/new" element={<AdminNewProductPage />} />
            <Route path="brands" element={<AdminBrandsPage />} />
            <Route path="categories" element={<AdminCategoriesPage />} />
            <Route path="inventory" element={<AdminInventoryPage />} />
            <Route path="orders" element={<AdminOrdersPage />} />
            <Route path="customers" element={<AdminCustomersPage />} />
            <Route path="promotions" element={<AdminPromotionsPage />} />
            <Route path="content" element={<AdminContentPage />} />
            <Route path="reports" element={<AdminReportsPage />} />
            <Route path="settings" element={<AdminSettingsPage />} />
          </Route>

          {/* Customer Storefront Routes */}
          <Route path="/*" element={<StoreLayout />} />
        </Routes>

        {/* Global Overlays */}
        <CartDrawer />
        <QuickViewModal />
        <ToastContainer />
      </Router>
    </StoreProvider>
  );
};

export default App;
